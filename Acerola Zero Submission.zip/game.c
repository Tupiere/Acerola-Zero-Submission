#include"main.h"

void game_init(){

}

void game_input(){

}

void game_update(){

}

void game_render(){

}

void game_framerate(){

}

void game_quit(){

}
