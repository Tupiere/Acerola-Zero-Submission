#include"main.h"

void pause_init(){

}

void pause_input(){

}

void pause_update(){

}

void pause_render(){

}

void pause_framerate(){

}

void pause_quit(){

}
